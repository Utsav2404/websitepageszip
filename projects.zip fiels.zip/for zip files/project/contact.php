<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href=".//style.css">
  <style> 
    /* Style for the contact us section */
    .contact {
      background-color: #f1f1f1;
      padding: 40px;
      text-align: center;
    }

    .contact h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    .contact p {
      font-size: 16px;
      line-height: 1.5;
      margin-bottom: 30px;
    }

    .contact-form {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
    }

    .contact-form input,
    .contact-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
    }

    .contact-form button {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      border: none;
      cursor: pointer;
    }
  </style>  
</head>
<body>
<!-- header files -->
<!-- <h1>Krinal Enterprise</h1>
    <h4>Jamnagar,Gujarat,India</h4>
    
  <header>
    <div class="container">
        <span class="logo"></span>
        <nav>
        <table>
            <tr>
                <th width="3%" align="left"> <a href=".//index.html"><u>Home</u></a> </th>
                <th width="6%" align="left"> <a href=".//about.html"><u>About</u></a> </th>
                <th width="9%" align="left"> <a href=".//services.php"><u>Services</u></a> </th>
                <th width="12%" align="left"> <a href=".//contact.html"><u>Contact</u></a> </th>
                <th width="15%" height="50px" bgcolor="#ff0253"><input type="text" placeholder="Search Product/Services" name="search"><button onclick="searchProducts">Search</button> </th>
            </tr>
        </table>
        
        </nav>
    </div>
  </header> -->

 <!-- contact section -->

  <section class="contact">
    <h2>Contact Us</h2>
    <p>Have any questions? Feel free to get in touch with us!</p>

    <!-- <form method="post" action=".//add.php"> -->
        <form method="Post">
      <div class="contact-form">
    
      <input type="text" placeholder="Your Name" name="name">
      <input type="email" placeholder="Your Email" name="email">
      <textarea placeholder="Your Message" name="product_de"></textarea>
      <input type="text" placeholder="Contact Number" name="mobile">
      <button type="submit" onclick="actionsend()">Send Message</button>
    
    </div>

  </form>
  </section>
  
  <!-- Rest of your HTML content goes here -->
  <script>
      function actionsend(){
        <?php
          $con=mysqli_connect("localhost","root" ,"","firstweb" )or die("Please Try Again");
          $a="insert into product values('".$_POST['name']."','".$_POST['product_de']."','".$_POST['mobile']."','".$_POST['email']."')";
          $result=mysqli_query($con,$a);

        ?>
      }
  </script>
  

</body>
</html>
