var global_array=new Array();var tid=0;var keycode=0;var req_search=null;var prev_hilighted_index=-1;var hilighted_index=-1;var enter=false;var result_bg_color='#FFFFFF';var result_fg_color='#0066CC';var result_hi_color='#CCCCCC';function search_keyword2(form,event,url){var error=0;if(!event&&window.event)
{event=window.event;}
if(document.layers)
{error=(event.modifiers&Event.CONTROL_MASK)>0;}
else
{error=event.ctrlKey;}
if(tid)
{return;}
keycode=event.keyCode;if(error)
{return true;}
if(isCtrlKey(keycode))
{return true;}
if(isSendKey(keycode))
{tid=setTimeout("SendQuery2('"+form+"','"+url+"')",100);}
return UpDown2(form,keycode);}
function isCtrlKey(key_code)
{if(key_code==16||key_code==17||key_code==18)
{return true;}
else
{return false;}}
function isSendKey(key_code)
{var code=true;switch(key_code){case 13:case 27:case 33:case 34:case 35:case 36:case 37:case 38:case 39:case 40:case 45:code=false;break;default:break;}
return code;}
function SendQuery2(fid,base_url){tid=0;var text_value=document.getElementById("global_search2").value;console.log(text_value);if(text_value.length!=0&&text_value.search(/\S/)!=-1)
{var url=base_url+'/design2017/components/search_data_xml.html?keyword='+encodeURIComponent(text_value);if(req_search)
{req_search.abort();}
req_search=(!window.XMLHttpRequest)?(ActiveXObject?(new ActiveXObject("Microsoft.XMLHTTP")):""):(new XMLHttpRequest());req_search.open("GET",url,true);req_search.onreadystatechange=new Function("Process2('"+fid+"')");req_search.send(null);}
else
{window.document.getElementById('h1_div2').style.visibility="hidden";window.document.getElementById('search-suggestion').style.visibility="hidden";hide_div2();}}
function Process2(fid)
{if(req_search.readyState==4)
{try
{if(req_search.status==200)
{if(req_search.responseText=="")
{alert('empty response got');hide_div2();}
else
{response=req_search.responseXML.documentElement;var list=response.getElementsByTagName('data');var gs=document.getElementById("global_search2");var dd=window.document.getElementById('sr_sugg2');ShowDiv2(fid);while(dd.childNodes.length>0)
{dd.removeChild(dd.childNodes[0]);}
if(list.length)
{window.document.getElementById('search-suggestion').style.visibility="visible";window.document.getElementById('h1_div2').style.visibility="visible";}
var html_res='';global_array=new Array();if(!list.length)
{window.document.getElementById('search-suggestion').style.visibility="visible";window.document.getElementById('drp_dwn2').style.visibility="hidden";window.document.getElementById('h1_div2').style.visibility="hidden";}
for(var i=0;i<list.length;i++)
{var search_term=list[i].getElementsByTagName("search")[0].firstChild.nodeValue;var count=list[i].getElementsByTagName("count")[0].firstChild.nodeValue;var headline=list[i].getElementsByTagName("headline")[0].firstChild.nodeValue;count='&nbsp;';global_array[i]=String(search_term);var new_el=document.createElement("a");new_el.setAttribute('class','suggestion-dynamic-item');new_el.id=i;var global_span=document.createElement("SPAN");global_span.id=String('global_'+i);var search_term_span=document.createElement("SPAN");search_term_span.id=String('search_'+i);search_term_span.innerHTML=search_term;search_term_span.innerHTML=headline;global_span.appendChild(search_term_span);new_el.appendChild(global_span);dd.appendChild(new_el);}
hilighted_index=-1;pre_hilighted_index=-1;enable_blur();var classHighlight='search_li_highlight';var $thumbs=jq('.suggestion-dynamic-item').click(function(e){e.preventDefault();jq('.suggestion-dynamic-item').removeClass(classHighlight);jq(this).addClass(classHighlight);var val=jq(this).text();document.getElementById("global_search2").value=val;window.document.getElementById('h1_div2').style.visibility="hidden";window.document.getElementById('search-suggestion').style.visibility="hidden";window.document.getElementById('sr_sugg2').style.visibility="hidden";});var $thumbs=jq('#search_btn').click(function(e){window.document.getElementById('h1_div2').style.visibility="hidden";window.document.getElementById('search-suggestion').style.visibility="hidden";});}}}
catch(e)
{alert("in catch"+e);}}}
function setStyle(obj,type)
{switch(type.charAt(0)){case "a":obj.style.visibility="visible";obj.style.width="80%";obj.style.fontSize="12px";obj.style.fontFamily="Verdana, Arial, Helvetica";obj.style.color=result_fg_color;obj.style.whiteSpace="nowrap";obj.style.styleFloat="left";obj.style.cssFloat="left";obj.style.textAlign="left";break;case "b":obj.style.visibility="visible";obj.style.width="20%";obj.style.fontSize="12px";obj.style.fontFamily="Verdana, Arial, Helvetica";obj.style.color="#0000DE";obj.style.styleFloat="right";obj.style.cssFloat="right";obj.style.textAlign="right";break;case "c":obj.style.width="100%";obj.style.weight="bold";obj.style.fontFamily="Verdana, Arial, Helvetica";obj.style.fontSize="15px";obj.style.styleFloat="left";obj.style.cssFloat="left";obj.style.textAlign="left";break;default:break;}}
function ShowDiv2(fid)
{document.getElementById('sr_sugg2').style.visibility="visible";}
function hide_div2()
{if(global_array.length)
{hide_all();}
document.getElementById('sr_sugg2').style.visibility="hidden";}
function hide_div_later()
{setTimeout("hide_div2()",100);}
function hide_all()
{for(var i=0;i<global_array.length;i++)
{document.getElementById('search_'+i).style.visibility="hidden";document.getElementById('global_'+i).style.visibility="hidden";document.getElementById(i).style.visibility="hidden";}}
UpDown2=function(form,key_code)
{if(handleCursorUpDownEnter2(key_code,form)||isShowKey(key_code))
{return true;}
else
{return false;}};function isShowKey(key_code)
{if(key_code==40||key_code==38||key_code==33||key_code==34||key_code==13){return false;}
else
{return true;}}
function handleCursorUpDownEnter2(key_code,form)
{var obj_div=document.getElementById('sr_sugg2');if(key_code==40)
{if(obj_div.style.visibility=="visible")
{highlightNewValue(Number(hilighted_index)+Number(1),key_code,form);return false;}}
else
{if(key_code==38)
{if(obj_div.style.visibility=="visible")
{highlightNewValue(hilighted_index-1,key_code,form);return false;}}
else
{if(key_code==13||key_code==3)
{if(key_code==13)
{enter=true;return submitHandlerIncr12(form);}
return false;}}}
if(keycode!=0)
{ForEachKeyPressed(keycode,form);}
return true;}
function highlightNewValue(index,key_code,form)
{if(index<0)
{if(prev_hilighted_index>=0)
{change_background(prev_hilighted_index,'2');prev_hilighted_index=-1;}
hilighted_index=-1;return;}
if(index>global_array.length-1)
{change_background(index-1,'1');hilighted_index=global_array.length-1;prev_hilighted_index=global_array.length-1;return;}
jq('#global_search').val(global_array[index]);if(key_code==40)
{if(prev_hilighted_index>=0)
{change_background(prev_hilighted_index,'2');}
change_background(index,'1');hilighted_index=index;prev_hilighted_index=index;}
if(key_code==38)
{if(prev_hilighted_index>=0)
{change_background(prev_hilighted_index,'2');}
change_background(index,'1');hilighted_index=index;prev_hilighted_index=index;}}
function change_background(index,color)
{switch(color.charAt(0))
{case "1":document.getElementById('search_'+index).style.backgroundColor=result_hi_color;document.getElementById(index).style.backgroundColor=result_hi_color;break;case "2":document.getElementById('search_'+index).style.backgroundColor=result_bg_color;document.getElementById(index).style.backgroundColor=result_bg_color;break;default:break;}}
function mouse_in(hh)
{basic_style();change_background(hh,'1');hilighted_index=hh;prev_hilighted_index=hh;disable_blur();}function mouse_out(hh)
{change_background(hh,'2');enable_blur();}
function enable_blur()
{var main_div=document.getElementById("global_search2");}
function disable_blur()
{var main_div=document.getElementById("global_search2");main_div.onblur=null;}
function basic_style()
{for(i=0;i<global_array.length;i++)
{change_background(i,'2');}}
function findPosX(obj)
{var curleft=0;if(obj.offsetParent)
{while(obj.offsetParent)
{curleft+=obj.offsetLeft;obj=obj.offsetParent;}}
else if(obj.x)
curleft+=obj.x;return curleft;}
function findPosY(obj)
{var curtop=0;if(obj.offsetParent)
{while(obj.offsetParent)
{curtop+=obj.offsetTop
obj=obj.offsetParent;}}
else if(obj.y)
curtop+=obj.y;return curtop;}
function ForEachKeyPressed(key_code,form)
{var ss=document.getElementById("global_search2");var ad=document.getElementById("sr_sugg2");var value=ss.value;var length=global_array.length;if(value==""||length==0||keycode==27||value.search(/\S/)==-1||(ad.style.visibility=="hidden"&&(keycode==35||keycode==36)))
{hide_div2();}}
function submitHandlerIncr12(form)
{var val=document.getElementById(hilighted_index).id;document.getElementById("global_search2").value=global_array[val];hide_div2();jq('.suggestion-dynamic-item').removeClass(classHighlight);window.document.getElementById('h1_div2').style.visibility="hidden";window.document.getElementById('search-suggestion').style.visibility="hidden";window.document.getElementById('sr_sugg2').style.visibility="hidden";document.global_search_form.submit();}
function submitItem(index)
{alert('submit');document.getElementById("global_search2").value=String(global_array[index]);hide_div2();}