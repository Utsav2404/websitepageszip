<!DOCTYPE html>
<html>
<head>
  <title>My Website</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    /* CSS styles for the header section */
     header {
      background-color: #abff3e;
      padding: 20px;
      
    }
    
    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    
    nav ul li {
      display: inline;
      margin-right: 10px;
    }
    
    .search-section {
      display: inline-block;
      margin-left: 10px;
      text-align: end;
    }
    
    .send-inquiry {
        background-color: #abff3e;
        text-align: center;
      display: inline-block;
      margin-left: 10px;
      text-align: end;
    } 
  </style>
</head>
<body>
    <h1>Krinal Enterprises</h1>
    <h4>Jamnagar,Gujarat,India</h4>
  <header>
    <nav>
    <ul >
        <li><a href=".//home.html">Home Page</a></li>
        <li><a href="#">Company Profile</a></li>
        <li><a href="#">Our Products+</a></li>
        <li><a href="#">Contact Us</a></li>
      
        <div class="search-section">
        <ul>
            <li > <input type="text" placeholder="Search..." ></li>
            <li><button type="submit">Search</button></li>
        </ul>
        </div>
        <div class="send-inquiry">
        <li><button type="button">Send Inquiry</button></li>
        </div>
    </ul>
    </nav>
  </header>
  
  <!-- Rest of your website content goes here -->
  
</body>
</html>


















<!-- <!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to My Website</h1>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>
         Content of the website goes here 
    </main>

    <footer>
         Footer content goes here 
    </footer>
</body>
</html> -->
