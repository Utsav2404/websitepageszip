<?php
    $con=mysqli_connect("localhost","root","","mysql") or die("could not connected");
?>