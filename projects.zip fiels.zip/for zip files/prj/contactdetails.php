<!-- <!<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <table>
                <tr aria-colspan="2">
                        <td>
                            <h1>Contact Details</h1>
                            <
                        </td>
                </tr>
            
        </table>
    </body>
</html> -->

<form name="h2h_form" id="h2h_form" class="form-bg" method="POST" action="/sourcing/mailer_sourcing_action.html">
                 <h2>We are here to help you! <br><span>Tell us what you need.</span></h2>
<div class="sourcing_div">
                    <input  type="text" name="description" id="product_name" value="" placeholder="Product name" class="contact-form-input sourcing_prod_name">
</div>
<div class="sourcing_div">
                    <input  type="text" id="h2h_email" name="email" placeholder="Enter Your Email" class="contact-form-input">
</div>
<div class="sourcing_div" style="margin-bottom:5px;">
                    <input type="tel" class="mobilep-input-box" id="h2h_phone" name="mobile_number" placeholder="Enter your mobile no." value="+91" style=" padding-left: 90px ! important; "/>
</div>
<div class="clear:both"></div>
<span id="span_co_name_city" style="display: none;" >
<div class="sourcing_div">
                        <dd class="div_loc">
                    <input  type="text" name="contact_person" placeholder="Enter Your Name" class="contact-form-input">
                    </dd>
</div>
<div class="sourcing_div">
                    <input id="qi_company_name"  type="text" name="company_name" placeholder="Enter Company Name" class="contact-form-input">
</div>
<div class="sourcing_div">
<dd id="show_pin_code" class="margin-right">
                    <input id="h2h_pincode"  type="text" name="h2h_pincode" placeholder="Pincode" class="contact-form-input">
</dd>
</div>
<div class="sourcing_div">
                    <dd id="city-dd" class="margin-left" style="display:none"">
		<style>
.ui-autocomplete {max-height: 200px; overflow-y: auto;}
/* IE 6 doesn't support max-height
 * we use height instead, but this forces the menu to always be this tall
 */
* html .ui-autocomplete {
  height: 100px;
}
.ui-menu {
        font-size: 9px;
}
.ui-menu-item {
        font-size: 9px;
}
.dialog_err {
  font-family: verdana;
  font-size: 8px;
  font-weight: bold;
  color: red;
  padding: 1px;
}
#city_nearest_branch{
    height:20px;
    border:1px solid #d8d8d8;
    width:150px;
    font-size: 1em;
    line-height:1.2em;
}
</style>
