<!-- <?php
    $con=mysqli_connect("localhost","root" ,"root","database_name" )or die("Please Try Again");
    $a="insert into product values('".$_POST['name']."','".$_POST['product_de']."','".$_POST['mobile']."','".$_POST['email']."')";
    $result=mysqli_query($con,$a);
?> 
<html>
    <body>
            <link rel="" href=".//index.html" >        
    </body>
</html> -->

<?php
// // Database configuration
// $servername = "localhost"; // Replace with your servername
// $username = "root"; // Replace with your username
// $password = ""; // Replace with your password
// $dbname = "firstweb"; // Replace with your database name

// // Create a new connection
// $conn = new mysqli($servername, $username, $password, $dbname) or die("Please Try Again");
// echo "Sucessfully Connected";

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Get form data
// $Name = $_POST['name'];
// $Email = $_POST['email'];
// $Phone = $_POST['mobile'];
// $ProductDetails = $_POST['product'];

// // Prepare and bind the SQL statement
// $stmt = $conn->prepare("INSERT INTO product (YourName, Product_Details, Mobile_No,E-Mail) VALUES (utsav, this  my firt website, 9484572400,abcd@gmail.com )");
// $stmt->bind_param("ssss", $Name, $Email, $Phone, $ProductDetails);

// // Execute the statement
// if ($stmt->execute()) {
//     echo "Record inserted successfully.";
// } else {
//     echo "Error: " . $stmt->error;
// }

// // Close the statement and connection
// $stmt->close();
// $conn->close();
// ?> 
