<!DOCTYPE html>
<html>
<head>
    <title>First Website Developed BY UTSAV PATEL</title>
</head>
<body>
    <h1>Welcome to the Combined Webpage!</h1>

    
    
    <iframe src=".//home.html" width="100%" height="400px" ></iframe>        
    <iframe src=".//photo.html" width="100%" height="400px" ></iframe>
    <iframe src=".//about.html" width="100%" height="?%" ></iframe>
    <iframe src=".//contact.php" width="100%" height="400px" ></iframe>
    <iframe src=".//footer.html" width="100%" height="400px" ></iframe> 
</body>
</html>
