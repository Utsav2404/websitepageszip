<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $message = $_POST["message"];

  // Email recipient
  $to = "putsav634@gmail.com";
  $subject = "New Inquiry from Contact Form";

  $headers = "From: " . $email . "\r\n";
  $headers .= "Reply-To: " . $email . "\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

  $emailBody = "<h2>Contact Details:</h2>
    <p><strong>Name:</strong> " . $name . "</p>
    <p><strong>Email:</strong> " . $email . "</p>
    <p><strong>Message:</strong> " . $message . "</p>";

  if (mail($to, $subject, $emailBody, $headers)) {
    // Email sent successfully
    echo "<p>Thank you for contacting us. We will get back to you soon!</p>";
  } else {
    // Failed to send email
    echo "<p>Sorry, there was an error sending your message. Please try again later.</p>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <!-- Add CSS styling here -->
  <style>
    .contact-form {
      width: 400px;
      margin: 0 auto;
    }
    .contact-form label,
    .contact-form input,
    .contact-form textarea {
      display: block;
      margin-bottom: 10px;
    }
    .contact-form textarea {
      height: 100px;
    }
    .contact-form button {
      padding: 10px 20px;
    }
  </style>
</head>
<body>
  <div class="contact-form">
    <h2>Contact Us</h2>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="message">Message:</label>
      <textarea id="message" name="message" required></textarea>

      <button type="submit">Submit</button>
    </form>
  </div>
</body>
</html>
