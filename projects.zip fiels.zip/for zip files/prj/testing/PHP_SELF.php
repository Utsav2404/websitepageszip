<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Rest of the code...

  if (mail($to, $subject, $emailBody, $headers)) {
    // Email sent successfully
    echo "<p>Thank you for contacting us. We will get back to you soon!</p>";

    // Create a file with the form data
    $fileContent = "Name: " . $name . "\n";
    $fileContent .= "Email: " . $email . "\n";
    $fileContent .= "Message: " . $message . "\n";

    $filename = "inquiry-" . time() . ".txt"; // Generate a unique filename using the current timestamp

    // Create the file in the same directory as this PHP file
    $file = fopen($filename, "w");
    fwrite($file, $fileContent);
    fclose($file);

    echo "<p>Form data saved in file: " . $filename . "</p>";
  } else {
    // Failed to send email
    echo "<p>Sorry, there was an error sending your message. Please try again later.</p>";
  }
}
?>
